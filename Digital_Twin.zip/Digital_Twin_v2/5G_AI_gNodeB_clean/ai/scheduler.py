import os
import joblib
import pandas as pd
from core.data_pipeline import compute_network_utility

FEATURES=["Distance","SINR","CQI","Traffic","BeamAngle","Throughput"]

class Scheduler:
    def __init__(self, model_path="ai/model.pkl"):
        self.model_path=model_path
        self.model=None
        if os.path.exists(model_path):
            try:
                self.model=joblib.load(model_path)
            except Exception:
                self.model=None

    def rank(self, df):
        out=compute_network_utility(df)
        if self.model is not None and all(c in out.columns for c in FEATURES):
            p=self.model.predict_proba(out[FEATURES])
            classes=list(self.model.classes_)
            if 1 in classes:
                ai_score=p[:, classes.index(1)]*100
                out["AI Score"]=ai_score.round(2)
                out["Decision Mode"]="Supervised Random Forest"
            else:
                out["AI Score"]=out["Network Score"]
                out["Decision Mode"]="Network utility"
        else:
            out["AI Score"]=out["Network Score"]
            out["Decision Mode"]="Network utility (no labeled model)"
        out=out.sort_values(["AI Score","Network Score"],ascending=False).reset_index(drop=True)
        out.insert(0,"Rank",range(1,len(out)+1))
        return out
