The model is intentionally optional.

If a real/historical dataset contains `Scheduled` (0/1), train:
`python ai/train_model.py --csv data/training_data.csv`

Until that exists, the application uses the transparent network-utility scheduler. This avoids the previous project's leakage problem where the target label was directly generated from the same features used to train the model.
