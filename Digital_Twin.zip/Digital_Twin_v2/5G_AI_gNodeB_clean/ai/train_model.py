import os
import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

# Ensure data directory exists
os.makedirs('data', exist_ok=True)
os.makedirs('ai', exist_ok=True)

data_path = 'data/training_data.csv'

# Generate synthetic training dataset if it doesn't exist
if not os.path.exists(data_path):
    print("Generating dataset at data/training_data.csv...")
    np.random.seed(42)
    n_samples = 1000

    distances = np.random.uniform(10, 500, n_samples)
    sinr = np.random.uniform(-5, 30, n_samples)
    cqi = np.random.randint(1, 16, n_samples)
    traffic = np.random.uniform(1, 100, n_samples)
    beam_angle = np.random.uniform(-60, 60, n_samples)
    throughput = np.random.uniform(5, 500, n_samples)

    # Power allocation feature (Allocated transmit power in dBm)
    power_dbm = np.random.uniform(10, 46, n_samples)

    # Priority score for AI scheduling label
    score = (cqi * 2.0) + (sinr * 1.5) + (throughput * 0.05) - (distances * 0.02) + (power_dbm * 0.5)
    labels = (score > np.median(score)).astype(int)

    df = pd.DataFrame({
        'Distance': distances,
        'SINR': sinr,
        'CQI': cqi,
        'Traffic': traffic,
        'Beam_Angle': beam_angle,
        'Throughput': throughput,
        'Power_dBm': power_dbm,
        'Selected': labels
    })

    df.to_csv(data_path, index=False)
    print("Dataset successfully generated!")

# Load dataset and train Random Forest model
df = pd.read_csv(data_path)
feature_cols = [c for c in df.columns if c != 'Selected']
X = df[feature_cols]
y = df['Selected']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

acc = model.score(X_test, y_test)
print(f"Model trained successfully! Accuracy: {acc * 100:.2f}%")

joblib.dump(model, 'ai/scheduler_model.joblib')
print("Saved model to ai/scheduler_model.joblib")