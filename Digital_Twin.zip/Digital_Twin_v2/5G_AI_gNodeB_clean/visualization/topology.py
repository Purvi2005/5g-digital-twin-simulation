import plotly.graph_objects as go

def make_topology(df, selected_user=None):
    fig=go.Figure()
    fig.add_trace(go.Scatter(
        x=[0],y=[0],mode="markers+text",
        marker=dict(size=28,color="#0B84A5",line=dict(color="#14213D",width=2)),
        text=["gNodeB"],textposition="bottom center",name="gNodeB",
        hovertemplate="<b>gNodeB</b><br>(0, 0)<extra></extra>"
    ))
    fig.add_trace(go.Scatter(
        x=df["X"],y=df["Y"],mode="markers+text",
        marker=dict(size=12,color="#4C78A8",line=dict(color="white",width=1)),
        text=df["User"],textposition="top center",name="UEs",
        customdata=df[["SINR","CQI","Throughput","AI Score"]].to_numpy(),
        hovertemplate="<b>%{text}</b><br>SINR: %{customdata[0]:.2f} dB<br>CQI: %{customdata[1]}<br>Throughput: %{customdata[2]:.2f} Mbps<br>Score: %{customdata[3]:.2f}<extra></extra>"
    ))
    if selected_user is not None and selected_user in set(df["User"]):
        r=df[df["User"].eq(selected_user)].iloc[0]
        fig.add_trace(go.Scatter(x=[r["X"]],y=[r["Y"]],mode="markers",
            marker=dict(size=24,color="#F59E0B",symbol="star",line=dict(color="#14213D",width=2)),
            name="Scheduled UE",hovertemplate=f"<b>Scheduled: {selected_user}</b><extra></extra>"))
        fig.add_trace(go.Scatter(x=[0,r["X"]],y=[0,r["Y"]],mode="lines",
            line=dict(color="#F59E0B",width=2,dash="dash"),name="Active Beam",hoverinfo="skip"))
    radius=max(500,float(df["Distance"].max())*1.1)
    fig.update_layout(title="Virtual gNodeB Topology",height=560,template="plotly_white",
        paper_bgcolor="white",plot_bgcolor="white",font=dict(color="#14213D"),
        xaxis=dict(title="X Position (m)",range=[-radius,radius],gridcolor="#E5E9EF"),
        yaxis=dict(title="Y Position (m)",range=[-radius,radius],gridcolor="#E5E9EF",scaleanchor="x",scaleratio=1),
        margin=dict(l=50,r=20,t=70,b=50))
    return fig
