% Convenience script for interactive MATLAB use.
inputFile=fullfile(pwd,'..','data','twin_input.csv');
outputFile=fullfile(pwd,'..','data','matlab_results.csv');
run_phy_simulation(inputFile,outputFile);
disp(readtable(outputFile));
