import numpy as np
import pandas as pd

class DigitalTwin:
    def __init__(self, num_ues_or_df=10, seed=None):
        self.seed = int(seed) if seed is not None else None
        self.cycle = 1  # Added cycle counter attribute
        
        # Check if the argument is a DataFrame or a numeric count
        if isinstance(num_ues_or_df, pd.DataFrame):
            self.current_data = num_ues_or_df
            self.num_ues = len(num_ues_or_df)
        else:
            self.current_data = None
            self.num_ues = int(num_ues_or_df)

    def generate_data(self):
        if self.seed is not None:
            np.random.seed(self.seed)
            
        num_ues_int = int(self.num_ues)
        
        distances = np.random.uniform(10, 500, num_ues_int)
        sinr = np.random.uniform(-5, 30, num_ues_int)
        cqi = np.random.randint(1, 16, num_ues_int)
        traffic = np.random.uniform(1, 100, num_ues_int)
        beam_angle = np.random.uniform(-60, 60, num_ues_int)
        throughput = np.random.uniform(5, 500, num_ues_int)
        
        # 5G Power Allocation Strategy:
        # Base power = 30 dBm, compensated for distance-dependent path loss and CQI demand
        base_power = 30.0
        path_loss_compensation = 10 * 2.0 * np.log10(distances / 10.0)
        power_dbm = np.clip(base_power + path_loss_compensation + (16 - cqi) * 0.5, 10.0, 46.0)

        df = pd.DataFrame({
            'UE_ID': [f'UE_{i+1}' for i in range(num_ues_int)],
            'Distance': np.round(distances, 2),
            'SINR': np.round(sinr, 2),
            'CQI': cqi,
            'Traffic': np.round(traffic, 2),
            'Beam_Angle': np.round(beam_angle, 2),
            'Throughput': np.round(throughput, 2),
            'Power_dBm': np.round(power_dbm, 2)
        })
        self.current_data = df
        return df

    def run_cycle(self, scheduler, data=None):
        """Runs a complete Digital Twin cycle: gets network data and evaluates scheduling via AI scheduler."""
        if data is None:
            if self.current_data is None:
                df = self.generate_data()
            else:
                df = self.current_data
        else:
            df = data

        # Use the scheduler/ranker to score users
        if scheduler is not None:
            if callable(scheduler):
                ranked_df = scheduler(df)
            elif hasattr(scheduler, 'schedule'):
                ranked_df, _ = scheduler.schedule(df)
            elif hasattr(scheduler, 'rank'):
                ranked_df = scheduler.rank(df)
            else:
                ranked_df = df
        else:
            ranked_df = df

        selected_ue = ranked_df.iloc[0] if isinstance(ranked_df, pd.DataFrame) and len(ranked_df) > 0 else None

        return ranked_df, selected_ue


def generate_digital_twin_data(num_ues=10, seed=None):
    dt = DigitalTwin(num_ues_or_df=num_ues, seed=seed)
    return dt.generate_data()