import numpy as np
import pandas as pd

REQUIRED = ["Distance", "SINR", "CQI", "Traffic", "BeamAngle", "Throughput"]

def validate_and_prepare(df: pd.DataFrame):
    if not isinstance(df, pd.DataFrame):
        return False, ["Data is not a table."], None
    df = df.copy()
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        return False, missing, None
    if df.empty:
        return False, ["Dataset is empty."], None

    for c in REQUIRED:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    bad = [c for c in REQUIRED if df[c].isna().any()]
    if bad:
        return False, [f"{c} contains missing/non-numeric values" for c in bad], None

    if "User" not in df.columns:
        df.insert(0, "User", [f"UE{i+1}" for i in range(len(df))])
    else:
        df["User"] = df["User"].astype(str)

    # Derive Cartesian position from polar measurements when needed.
    if "X" not in df.columns or "Y" not in df.columns:
        theta = np.deg2rad(df["BeamAngle"].to_numpy())
        df["X"] = df["Distance"] * np.cos(theta)
        df["Y"] = df["Distance"] * np.sin(theta)

    # Sanity checks, not silent clipping.
    if (df["Distance"] < 0).any():
        return False, ["Distance cannot be negative."], None
    if (df["CQI"] < 0).any() or (df["CQI"] > 15).any():
        return False, ["CQI must be between 0 and 15."], None

    df["Distance"] = df["Distance"].round(2)
    df["SINR"] = df["SINR"].round(2)
    df["CQI"] = df["CQI"].round().astype(int)
    df["Traffic"] = df["Traffic"].round(2)
    df["BeamAngle"] = df["BeamAngle"].round(2)
    df["Throughput"] = df["Throughput"].round(2)
    df["X"] = df["X"].round(2)
    df["Y"] = df["Y"].round(2)
    return True, [], df

def minmax(s):
    lo, hi = float(s.min()), float(s.max())
    if hi-lo < 1e-12:
        return pd.Series(np.full(len(s), 0.5), index=s.index)
    return (s-lo)/(hi-lo)

def compute_network_utility(df):
    out=df.copy()
    sinr=minmax(out["SINR"])
    cqi=out["CQI"]/15.0
    thr=minmax(out["Throughput"])
    demand=minmax(out["Traffic"])
    distance=1-minmax(out["Distance"])
    # A transparent scheduling objective: channel quality + useful service + demand.
    out["Network Score"]=(100*(0.30*sinr+0.20*cqi+0.25*thr+0.15*demand+0.10*distance)).round(2)
    return out
