# AI-Enabled 5G gNodeB Digital Twin

A clean prototype of a 5G gNodeB digital twin with:
- simulation or CSV network-state ingestion
- CSV validation and normalization
- AI-assisted user scheduling
- a stateful digital-twin cycle
- Plotly topology visualization
- optional MATLAB PHY simulation

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## MATLAB
The app can call MATLAB in batch mode if MATLAB is installed and its executable is configured/available.
The MATLAB script reads `data/twin_input.csv` and writes `data/matlab_results.csv`.

The Python application still works in "Python-only" mode if MATLAB is unavailable; the UI will clearly label the PHY result as unavailable rather than pretending it is a MATLAB result.

## Dataset
The CSV interface accepts these columns:
`User, Distance, SINR, CQI, Traffic, BeamAngle, Throughput`

Optional columns:
`Timestamp, X, Y, RSRP, RSRQ, MCS, PRB_Utilization, Latency, PacketLoss`

If X/Y are absent, they are derived from Distance and BeamAngle.

If a historical `Scheduled` column exists, it can be used to train a supervised Random Forest. Without a label, the app uses a transparent network-utility scheduler; it does not fabricate an AI confidence score.


## Important MATLAB behavior
The application deletes the previous `data/matlab_results.csv` before every
twin cycle. MATLAB then reads the newly selected UE from `data/twin_input.csv`
and overwrites the result file. Therefore the dashboard never falls back to
stale PHY values.

If MATLAB is not on your system PATH, enter the full path to `matlab.exe` in
the sidebar. The app will show an error instead of displaying an old result.
